const Client = require('bitcoin-core');

const fs = require('fs');
const client = new Client({ port: 28332 });
client.getInfo().then((help) => console.log(help));